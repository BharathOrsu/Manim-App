###### Class kotlin.UInt (kotlin.UInt)
.class public final Lkotlin/UInt;
.super Ljava/lang/Object;
.source "UInt.kt"

# interfaces
.implements Ljava/lang/Comparable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lkotlin/UInt$Companion;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/lang/Comparable<",
        "Lkotlin/UInt;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000n\n\u0002\u0018\u0002\n\u0002\u0010\u000f\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008-\n\u0002\u0018\u0002\n\u0002\u0008\u0012\n\u0002\u0010\u0005\n\u0002\u0008\u0003\n\u0002\u0010\n\n\u0002\u0008\u0005\n\u0002\u0010\t\n\u0002\u0008\u000b\n\u0002\u0010\u0007\n\u0002\u0008\u0003\n\u0002\u0010\u0006\n\u0002\u0008\u0003\n\u0002\u0010\u000e\n\u0002\u0008\u0003\n\u0002\u0010\u000b\n\u0002\u0010\u0000\n\u0002\u0008\u0003\u0008\u0087@\u0018\u0000 x2\u0008\u0012\u0004\u0012\u00020\u00000\u0001:\u0001xB\u0011\u0008\u0001\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J\u0018\u0010\u0008\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\nH\u0087\n\u00a2\u0006\u0004\u0008\u000b\u0010\u000cJ\u0018\u0010\u0008\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\rH\u0087\n\u00a2\u0006\u0004\u0008\u000e\u0010\u000fJ\u0018\u0010\u0008\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\u0000H\u0097\n\u00a2\u0006\u0004\u0008\u0010\u0010\u0011J\u0018\u0010\u0008\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\u0012H\u0087\n\u00a2\u0006\u0004\u0008\u0013\u0010\u0014J\u0018\u0010\u0015\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\nH\u0087\n\u00a2\u0006\u0004\u0008\u0016\u0010\u000cJ\u0018\u0010\u0015\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\rH\u0087\n\u00a2\u0006\u0004\u0008\u0017\u0010\u000fJ\u0018\u0010\u0015\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008\u0018\u0010\u0011J\u0018\u0010\u0015\u001a\u00020\u00122\u0006\u0010\t\u001a\u00020\u0012H\u0087\n\u00a2\u0006\u0004\u0008\u0019\u0010\u001aJ\u0018\u0010\u001b\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\nH\u0087\n\u00a2\u0006\u0004\u0008\u001c\u0010\u000cJ\u0018\u0010\u001b\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\rH\u0087\n\u00a2\u0006\u0004\u0008\u001d\u0010\u000fJ\u0018\u0010\u001b\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008\u001e\u0010\u0011J\u0018\u0010\u001b\u001a\u00020\u00122\u0006\u0010\t\u001a\u00020\u0012H\u0087\n\u00a2\u0006\u0004\u0008\u001f\u0010\u001aJ\u0018\u0010 \u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\nH\u0087\n\u00a2\u0006\u0004\u0008!\u0010\u000cJ\u0018\u0010 \u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\rH\u0087\n\u00a2\u0006\u0004\u0008\"\u0010\u000fJ\u0018\u0010 \u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008#\u0010\u0011J\u0018\u0010 \u001a\u00020\u00122\u0006\u0010\t\u001a\u00020\u0012H\u0087\n\u00a2\u0006\u0004\u0008$\u0010\u001aJ\u0018\u0010%\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\nH\u0087\n\u00a2\u0006\u0004\u0008&\u0010\u000cJ\u0018\u0010%\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\rH\u0087\n\u00a2\u0006\u0004\u0008\'\u0010\u000fJ\u0018\u0010%\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008(\u0010\u0011J\u0018\u0010%\u001a\u00020\u00122\u0006\u0010\t\u001a\u00020\u0012H\u0087\n\u00a2\u0006\u0004\u0008)\u0010\u001aJ\u0018\u0010*\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\nH\u0087\n\u00a2\u0006\u0004\u0008+\u0010\u000cJ\u0018\u0010*\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\rH\u0087\n\u00a2\u0006\u0004\u0008,\u0010\u000fJ\u0018\u0010*\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008-\u0010\u0011J\u0018\u0010*\u001a\u00020\u00122\u0006\u0010\t\u001a\u00020\u0012H\u0087\n\u00a2\u0006\u0004\u0008.\u0010\u001aJ\u0018\u0010/\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\nH\u0087\u0008\u00a2\u0006\u0004\u00080\u0010\u000cJ\u0018\u0010/\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\rH\u0087\u0008\u00a2\u0006\u0004\u00081\u0010\u000fJ\u0018\u0010/\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\u0008\u00a2\u0006\u0004\u00082\u0010\u0011J\u0018\u0010/\u001a\u00020\u00122\u0006\u0010\t\u001a\u00020\u0012H\u0087\u0008\u00a2\u0006\u0004\u00083\u0010\u001aJ\u0018\u00104\u001a\u00020\n2\u0006\u0010\t\u001a\u00020\nH\u0087\u0008\u00a2\u0006\u0004\u00085\u00106J\u0018\u00104\u001a\u00020\r2\u0006\u0010\t\u001a\u00020\rH\u0087\u0008\u00a2\u0006\u0004\u00087\u00108J\u0018\u00104\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\u0008\u00a2\u0006\u0004\u00089\u0010\u0011J\u0018\u00104\u001a\u00020\u00122\u0006\u0010\t\u001a\u00020\u0012H\u0087\u0008\u00a2\u0006\u0004\u0008:\u0010\u001aJ\u0010\u0010;\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008<\u0010\u0005J\u0010\u0010=\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008>\u0010\u0005J\u0018\u0010?\u001a\u00020@2\u0006\u0010\t\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008A\u0010BJ\u0018\u0010C\u001a\u00020@2\u0006\u0010\t\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008D\u0010BJ\u0018\u0010E\u001a\u00020\u00002\u0006\u0010F\u001a\u00020\u0003H\u0087\u000c\u00a2\u0006\u0004\u0008G\u0010\u0011J\u0018\u0010H\u001a\u00020\u00002\u0006\u0010F\u001a\u00020\u0003H\u0087\u000c\u00a2\u0006\u0004\u0008I\u0010\u0011J\u0018\u0010J\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\u000c\u00a2\u0006\u0004\u0008K\u0010\u0011J\u0018\u0010L\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\u000c\u00a2\u0006\u0004\u0008M\u0010\u0011J\u0018\u0010N\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\u000c\u00a2\u0006\u0004\u0008O\u0010\u0011J\u0010\u0010P\u001a\u00020\u0000H\u0087\u0008\u00a2\u0006\u0004\u0008Q\u0010\u0005J\u0010\u0010R\u001a\u00020SH\u0087\u0008\u00a2\u0006\u0004\u0008T\u0010UJ\u0010\u0010V\u001a\u00020WH\u0087\u0008\u00a2\u0006\u0004\u0008X\u0010YJ\u0010\u0010Z\u001a\u00020\u0003H\u0087\u0008\u00a2\u0006\u0004\u0008[\u0010\u0005J\u0010\u0010\\\u001a\u00020]H\u0087\u0008\u00a2\u0006\u0004\u0008^\u0010_J\u0010\u0010`\u001a\u00020\nH\u0087\u0008\u00a2\u0006\u0004\u0008a\u0010UJ\u0010\u0010b\u001a\u00020\rH\u0087\u0008\u00a2\u0006\u0004\u0008c\u0010YJ\u0010\u0010d\u001a\u00020\u0000H\u0087\u0008\u00a2\u0006\u0004\u0008e\u0010\u0005J\u0010\u0010f\u001a\u00020\u0012H\u0087\u0008\u00a2\u0006\u0004\u0008g\u0010_J\u0010\u0010h\u001a\u00020iH\u0087\u0008\u00a2\u0006\u0004\u0008j\u0010kJ\u0010\u0010l\u001a\u00020mH\u0087\u0008\u00a2\u0006\u0004\u0008n\u0010oJ\u000f\u0010p\u001a\u00020qH\u0016\u00a2\u0006\u0004\u0008r\u0010sJ\u0013\u0010t\u001a\u00020u2\u0008\u0010\t\u001a\u0004\u0018\u00010vH\u00d6\u0003J\t\u0010w\u001a\u00020\u0003H\u00d6\u0001R\u0016\u0010\u0002\u001a\u00020\u00038\u0000X\u0081\u0004\u00a2\u0006\u0008\n\u0000\u0012\u0004\u0008\u0006\u0010\u0007\u0088\u0001\u0002\u0092\u0001\u00020\u0003\u00a8\u0006y"
    }
    d2 = {
        "Lkotlin/UInt;",
        "",
        "data",
        "",
        "constructor-impl",
        "(I)I",
        "getData$annotations",
        "()V",
        "compareTo",
        "other",
        "Lkotlin/UByte;",
        "compareTo-7apg3OU",
        "(IB)I",
        "Lkotlin/UShort;",
        "compareTo-xj2QHRw",
        "(IS)I",
        "compareTo-WZ4Q5Ns",
        "(II)I",
        "Lkotlin/ULong;",
        "compareTo-VKZWuLQ",
        "(IJ)I",
        "plus",
        "plus-7apg3OU",
        "plus-xj2QHRw",
        "plus-WZ4Q5Ns",
        "plus-VKZWuLQ",
        "(IJ)J",
        "minus",
        "minus-7apg3OU",
        "minus-xj2QHRw",
        "minus-WZ4Q5Ns",
        "minus-VKZWuLQ",
        "times",
        "times-7apg3OU",
        "times-xj2QHRw",
        "times-WZ4Q5Ns",
        "times-VKZWuLQ",
        "div",
        "div-7apg3OU",
        "div-xj2QHRw",
        "div-WZ4Q5Ns",
        "div-VKZWuLQ",
        "rem",
        "rem-7apg3OU",
        "rem-xj2QHRw",
        "rem-WZ4Q5Ns",
        "rem-VKZWuLQ",
        "floorDiv",
        "floorDiv-7apg3OU",
        "floorDiv-xj2QHRw",
        "floorDiv-WZ4Q5Ns",
        "floorDiv-VKZWuLQ",
        "mod",
        "mod-7apg3OU",
        "(IB)B",
        "mod-xj2QHRw",
        "(IS)S",
        "mod-WZ4Q5Ns",
        "mod-VKZWuLQ",
        "inc",
        "inc-pVg5ArA",
        "dec",
        "dec-pVg5ArA",
        "rangeTo",
        "Lkotlin/ranges/UIntRange;",
        "rangeTo-WZ4Q5Ns",
        "(II)Lkotlin/ranges/UIntRange;",
        "rangeUntil",
        "rangeUntil-WZ4Q5Ns",
        "shl",
        "bitCount",
        "shl-pVg5ArA",
        "shr",
        "shr-pVg5ArA",
        "and",
        "and-WZ4Q5Ns",
        "or",
        "or-WZ4Q5Ns",
        "xor",
        "xor-WZ4Q5Ns",
        "inv",
        "inv-pVg5ArA",
        "toByte",
        "",
        "toByte-impl",
        "(I)B",
        "toShort",
        "",
        "toShort-impl",
        "(I)S",
        "toInt",
        "toInt-impl",
        "toLong",
        "",
        "toLong-impl",
        "(I)J",
        "toUByte",
        "toUByte-w2LRezQ",
        "toUShort",
        "toUShort-Mh2AYeg",
        "toUInt",
        "toUInt-pVg5ArA",
        "toULong",
        "toULong-s-VKNKU",
        "toFloat",
        "",
        "toFloat-impl",
        "(I)F",
        "toDouble",
        "",
        "toDouble-impl",
        "(I)D",
        "toString",
        "",
        "toString-impl",
        "(I)Ljava/lang/String;",
        "equals",
        "",
        "",
        "hashCode",
        "Companion",
        "kotlin-stdlib"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lkotlin/jvm/JvmInline;
.end annotation


# static fields
.field public static final Companion:Lkotlin/UInt$Companion;

.field public static final MAX_VALUE:I = -0x1

.field public static final MIN_VALUE:I = 0x0

.field public static final SIZE_BITS:I = 0x20

.field public static final SIZE_BYTES:I = 0x4


# instance fields
.field private final data:I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lkotlin/UInt$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lkotlin/UInt$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lkotlin/UInt;->Companion:Lkotlin/UInt$Companion;

    return-void
.end method

.method private synthetic constructor <init>(I)V
    .registers 2
    .param p1, "data"    # I

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lkotlin/UInt;->data:I

    return-void
.end method

.method private static final and-WZ4Q5Ns(II)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # I

    .line 271
    and-int v0, p0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method public static final synthetic box-impl(I)Lkotlin/UInt;
    .registers 2

    new-instance v0, Lkotlin/UInt;

    invoke-direct {v0, p0}, Lkotlin/UInt;-><init>(I)V

    return-object v0
.end method

.method private static final compareTo-7apg3OU(IB)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # B

    .line 47
    and-int/lit16 v0, p1, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    invoke-static {p0, v0}, Ljava/lang/Integer;->compareUnsigned(II)I

    move-result v0

    return v0
.end method

.method private static final compareTo-VKZWuLQ(IJ)I
    .registers 7
    .param p0, "arg0"    # I
    .param p1, "other"    # J

    .line 72
    int-to-long v0, p0

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {v0, v1, p1, p2}, Ljava/lang/Long;->compareUnsigned(JJ)I

    move-result v0

    return v0
.end method

.method private compareTo-WZ4Q5Ns(I)I
    .registers 3
    .param p1, "other"    # I

    invoke-virtual {p0}, Lkotlin/UInt;->unbox-impl()I

    move-result v0

    .line 62
    invoke-static {v0, p1}, Lkotlin/UnsignedKt;->uintCompare(II)I

    move-result v0

    .line 64
    return v0
.end method

.method private static compareTo-WZ4Q5Ns(II)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # I

    .line 64
    invoke-static {p0, p1}, Lkotlin/UnsignedKt;->uintCompare(II)I

    move-result v0

    return v0
.end method

.method private static final compareTo-xj2QHRw(IS)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # S

    .line 55
    const v0, 0xffff

    and-int/2addr v0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    invoke-static {p0, v0}, Ljava/lang/Integer;->compareUnsigned(II)I

    move-result v0

    return v0
.end method

.method public static constructor-impl(I)I
    .registers 1

    return p0
.end method

.method private static final dec-pVg5ArA(I)I
    .registers 2
    .param p0, "arg0"    # I

    .line 235
    add-int/lit8 v0, p0, -0x1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final div-7apg3OU(IB)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # B

    .line 115
    and-int/lit16 v0, p1, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    invoke-static {p0, v0}, Ljava/lang/Integer;->divideUnsigned(II)I

    move-result v0

    return v0
.end method

.method private static final div-VKZWuLQ(IJ)J
    .registers 7
    .param p0, "arg0"    # I
    .param p1, "other"    # J

    .line 124
    int-to-long v0, p0

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {v0, v1, p1, p2}, Ljava/lang/Long;->divideUnsigned(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final div-WZ4Q5Ns(II)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # I

    .line 121
    invoke-static {p0, p1}, Lkotlin/UnsignedKt;->uintDivide-J1ME1BU(II)I

    move-result v0

    return v0
.end method

.method private static final div-xj2QHRw(IS)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # S

    .line 118
    const v0, 0xffff

    and-int/2addr v0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    invoke-static {p0, v0}, Ljava/lang/Integer;->divideUnsigned(II)I

    move-result v0

    return v0
.end method

.method public static equals-impl(ILjava/lang/Object;)Z
    .registers 4

    instance-of v0, p1, Lkotlin/UInt;

    const/4 v1, 0x0

    if-nez v0, :cond_6

    return v1

    :cond_6
    move-object v0, p1

    check-cast v0, Lkotlin/UInt;

    invoke-virtual {v0}, Lkotlin/UInt;->unbox-impl()I

    move-result v0

    if-eq p0, v0, :cond_10

    return v1

    :cond_10
    const/4 v0, 0x1

    return v0
.end method

.method public static final equals-impl0(II)Z
    .registers 3

    if-ne p0, p1, :cond_4

    const/4 v0, 0x1

    goto :goto_5

    :cond_4
    const/4 v0, 0x0

    :goto_5
    return v0
.end method

.method private static final floorDiv-7apg3OU(IB)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # B

    .line 161
    and-int/lit16 v0, p1, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    invoke-static {p0, v0}, Ljava/lang/Integer;->divideUnsigned(II)I

    move-result v0

    return v0
.end method

.method private static final floorDiv-VKZWuLQ(IJ)J
    .registers 7
    .param p0, "arg0"    # I
    .param p1, "other"    # J

    .line 182
    int-to-long v0, p0

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {v0, v1, p1, p2}, Ljava/lang/Long;->divideUnsigned(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final floorDiv-WZ4Q5Ns(II)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # I

    .line 175
    invoke-static {p0, p1}, Ljava/lang/Integer;->divideUnsigned(II)I

    move-result v0

    return v0
.end method

.method private static final floorDiv-xj2QHRw(IS)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # S

    .line 168
    const v0, 0xffff

    and-int/2addr v0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    invoke-static {p0, v0}, Ljava/lang/Integer;->divideUnsigned(II)I

    move-result v0

    return v0
.end method

.method public static synthetic getData$annotations()V
    .registers 0

    return-void
.end method

.method public static hashCode-impl(I)I
    .registers 2

    invoke-static {p0}, Ljava/lang/Integer;->hashCode(I)I

    move-result v0

    return v0
.end method

.method private static final inc-pVg5ArA(I)I
    .registers 2
    .param p0, "arg0"    # I

    .line 227
    add-int/lit8 v0, p0, 0x1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final inv-pVg5ArA(I)I
    .registers 2
    .param p0, "arg0"    # I

    .line 280
    not-int v0, p0

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final minus-7apg3OU(IB)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # B

    .line 89
    and-int/lit16 v0, p1, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    sub-int v0, p0, v0

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final minus-VKZWuLQ(IJ)J
    .registers 7
    .param p0, "arg0"    # I
    .param p1, "other"    # J

    .line 98
    int-to-long v0, p0

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    sub-long/2addr v0, p1

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final minus-WZ4Q5Ns(II)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # I

    .line 95
    sub-int v0, p0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final minus-xj2QHRw(IS)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # S

    .line 92
    const v0, 0xffff

    and-int/2addr v0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    sub-int v0, p0, v0

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final mod-7apg3OU(IB)B
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # B

    .line 192
    and-int/lit16 v0, p1, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    invoke-static {p0, v0}, Ljava/lang/Integer;->remainderUnsigned(II)I

    move-result v0

    int-to-byte v0, v0

    invoke-static {v0}, Lkotlin/UByte;->constructor-impl(B)B

    move-result v0

    return v0
.end method

.method private static final mod-VKZWuLQ(IJ)J
    .registers 7
    .param p0, "arg0"    # I
    .param p1, "other"    # J

    .line 219
    int-to-long v0, p0

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {v0, v1, p1, p2}, Ljava/lang/Long;->remainderUnsigned(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final mod-WZ4Q5Ns(II)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # I

    .line 210
    invoke-static {p0, p1}, Ljava/lang/Integer;->remainderUnsigned(II)I

    move-result v0

    return v0
.end method

.method private static final mod-xj2QHRw(IS)S
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # S

    .line 201
    const v0, 0xffff

    and-int/2addr v0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    invoke-static {p0, v0}, Ljava/lang/Integer;->remainderUnsigned(II)I

    move-result v0

    int-to-short v0, v0

    invoke-static {v0}, Lkotlin/UShort;->constructor-impl(S)S

    move-result v0

    return v0
.end method

.method private static final or-WZ4Q5Ns(II)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # I

    .line 274
    or-int v0, p0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final plus-7apg3OU(IB)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # B

    .line 76
    and-int/lit16 v0, p1, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    add-int/2addr v0, p0

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final plus-VKZWuLQ(IJ)J
    .registers 7
    .param p0, "arg0"    # I
    .param p1, "other"    # J

    .line 85
    int-to-long v0, p0

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    add-long/2addr v0, p1

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final plus-WZ4Q5Ns(II)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # I

    .line 82
    add-int v0, p0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final plus-xj2QHRw(IS)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # S

    .line 79
    const v0, 0xffff

    and-int/2addr v0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    add-int/2addr v0, p0

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final rangeTo-WZ4Q5Ns(II)Lkotlin/ranges/UIntRange;
    .registers 4
    .param p0, "arg0"    # I
    .param p1, "other"    # I

    .line 239
    new-instance v0, Lkotlin/ranges/UIntRange;

    const/4 v1, 0x0

    invoke-direct {v0, p0, p1, v1}, Lkotlin/ranges/UIntRange;-><init>(IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object v0
.end method

.method private static final rangeUntil-WZ4Q5Ns(II)Lkotlin/ranges/UIntRange;
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # I

    .line 249
    invoke-static {p0, p1}, Lkotlin/ranges/URangesKt;->until-J1ME1BU(II)Lkotlin/ranges/UIntRange;

    move-result-object v0

    return-object v0
.end method

.method private static final rem-7apg3OU(IB)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # B

    .line 132
    and-int/lit16 v0, p1, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    invoke-static {p0, v0}, Ljava/lang/Integer;->remainderUnsigned(II)I

    move-result v0

    return v0
.end method

.method private static final rem-VKZWuLQ(IJ)J
    .registers 7
    .param p0, "arg0"    # I
    .param p1, "other"    # J

    .line 153
    int-to-long v0, p0

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {v0, v1, p1, p2}, Ljava/lang/Long;->remainderUnsigned(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final rem-WZ4Q5Ns(II)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # I

    .line 146
    invoke-static {p0, p1}, Lkotlin/UnsignedKt;->uintRemainder-J1ME1BU(II)I

    move-result v0

    return v0
.end method

.method private static final rem-xj2QHRw(IS)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # S

    .line 139
    const v0, 0xffff

    and-int/2addr v0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    invoke-static {p0, v0}, Ljava/lang/Integer;->remainderUnsigned(II)I

    move-result v0

    return v0
.end method

.method private static final shl-pVg5ArA(II)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "bitCount"    # I

    .line 258
    shl-int v0, p0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final shr-pVg5ArA(II)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "bitCount"    # I

    .line 267
    ushr-int v0, p0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final times-7apg3OU(IB)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # B

    .line 102
    and-int/lit16 v0, p1, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    mul-int/2addr v0, p0

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final times-VKZWuLQ(IJ)J
    .registers 7
    .param p0, "arg0"    # I
    .param p1, "other"    # J

    .line 111
    int-to-long v0, p0

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    mul-long/2addr v0, p1

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final times-WZ4Q5Ns(II)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # I

    .line 108
    mul-int v0, p0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final times-xj2QHRw(IS)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # S

    .line 105
    const v0, 0xffff

    and-int/2addr v0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    mul-int/2addr v0, p0

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final toByte-impl(I)B
    .registers 2
    .param p0, "arg0"    # I

    .line 292
    int-to-byte v0, p0

    return v0
.end method

.method private static final toDouble-impl(I)D
    .registers 3
    .param p0, "arg0"    # I

    .line 374
    invoke-static {p0}, Lkotlin/UnsignedKt;->uintToDouble(I)D

    move-result-wide v0

    return-wide v0
.end method

.method private static final toFloat-impl(I)F
    .registers 3
    .param p0, "arg0"    # I

    .line 367
    invoke-static {p0}, Lkotlin/UnsignedKt;->uintToDouble(I)D

    move-result-wide v0

    double-to-float v0, v0

    return v0
.end method

.method private static final toInt-impl(I)I
    .registers 1
    .param p0, "arg0"    # I

    .line 313
    return p0
.end method

.method private static final toLong-impl(I)J
    .registers 5
    .param p0, "arg0"    # I

    .line 323
    int-to-long v0, p0

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    return-wide v0
.end method

.method private static final toShort-impl(I)S
    .registers 2
    .param p0, "arg0"    # I

    .line 303
    int-to-short v0, p0

    return v0
.end method

.method public static toString-impl(I)Ljava/lang/String;
    .registers 5
    .param p0, "arg0"    # I

    .line 376
    int-to-long v0, p0

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final toUByte-w2LRezQ(I)B
    .registers 2
    .param p0, "arg0"    # I

    .line 334
    int-to-byte v0, p0

    invoke-static {v0}, Lkotlin/UByte;->constructor-impl(B)B

    move-result v0

    return v0
.end method

.method private static final toUInt-pVg5ArA(I)I
    .registers 1
    .param p0, "arg0"    # I

    .line 347
    return p0
.end method

.method private static final toULong-s-VKNKU(I)J
    .registers 5
    .param p0, "arg0"    # I

    .line 357
    int-to-long v0, p0

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final toUShort-Mh2AYeg(I)S
    .registers 2
    .param p0, "arg0"    # I

    .line 344
    int-to-short v0, p0

    invoke-static {v0}, Lkotlin/UShort;->constructor-impl(S)S

    move-result v0

    return v0
.end method

.method private static final xor-WZ4Q5Ns(II)I
    .registers 3
    .param p0, "arg0"    # I
    .param p1, "other"    # I

    .line 277
    xor-int v0, p0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method


# virtual methods
.method public bridge synthetic compareTo(Ljava/lang/Object;)I
    .registers 4
    .param p1, "other"    # Ljava/lang/Object;

    .line 14
    move-object v0, p1

    check-cast v0, Lkotlin/UInt;

    invoke-virtual {v0}, Lkotlin/UInt;->unbox-impl()I

    move-result v0

    invoke-virtual {p0}, Lkotlin/UInt;->unbox-impl()I

    move-result v1

    invoke-static {v1, v0}, Lkotlin/UnsignedKt;->uintCompare(II)I

    move-result v0

    return v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 3

    iget v0, p0, Lkotlin/UInt;->data:I

    invoke-static {v0, p1}, Lkotlin/UInt;->equals-impl(ILjava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public hashCode()I
    .registers 2

    iget v0, p0, Lkotlin/UInt;->data:I

    invoke-static {v0}, Lkotlin/UInt;->hashCode-impl(I)I

    move-result v0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 2

    .line 376
    iget v0, p0, Lkotlin/UInt;->data:I

    invoke-static {v0}, Lkotlin/UInt;->toString-impl(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final synthetic unbox-impl()I
    .registers 2

    iget v0, p0, Lkotlin/UInt;->data:I

    return v0
.end method

###### Class kotlin.UInt.Companion (kotlin.UInt$Companion)
.class public final Lkotlin/UInt$Companion;
.super Ljava/lang/Object;
.source "UInt.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlin/UInt;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Companion"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0002\u0008\u0002\u0008\u0086\u0003\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003R\u0010\u0010\u0004\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0004\n\u0002\u0010\u0006R\u0010\u0010\u0007\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0004\n\u0002\u0010\u0006R\u000e\u0010\u0008\u001a\u00020\tX\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\tX\u0086T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000b"
    }
    d2 = {
        "Lkotlin/UInt$Companion;",
        "",
        "<init>",
        "()V",
        "MIN_VALUE",
        "Lkotlin/UInt;",
        "I",
        "MAX_VALUE",
        "SIZE_BYTES",
        "",
        "SIZE_BITS",
        "kotlin-stdlib"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 19
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 2

    invoke-direct {p0}, Lkotlin/UInt$Companion;-><init>()V

    return-void
.end method
