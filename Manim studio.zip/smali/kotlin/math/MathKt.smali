###### Class kotlin.math.MathKt (kotlin.math.MathKt)
.class public final Lkotlin/math/MathKt;
.super Lkotlin/math/MathKt__MathJVMKt;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "kotlin/math/MathKt__MathHKt",
        "kotlin/math/MathKt__MathJVMKt"
    }
    k = 0x4
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x31
.end annotation


# static fields
.field public static final E:D = 2.718281828459045

.field public static final PI:D = 3.141592653589793


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Lkotlin/math/MathKt__MathJVMKt;-><init>()V

    return-void
.end method
