###### Class kotlin.UShort (kotlin.UShort)
.class public final Lkotlin/UShort;
.super Ljava/lang/Object;
.source "UShort.kt"

# interfaces
.implements Ljava/lang/Comparable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lkotlin/UShort$Companion;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/lang/Comparable<",
        "Lkotlin/UShort;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000l\n\u0002\u0018\u0002\n\u0002\u0010\u000f\n\u0000\n\u0002\u0010\n\n\u0002\u0008\u0005\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008-\n\u0002\u0018\u0002\n\u0002\u0008\r\n\u0002\u0010\u0005\n\u0002\u0008\u0008\n\u0002\u0010\t\n\u0002\u0008\u000b\n\u0002\u0010\u0007\n\u0002\u0008\u0003\n\u0002\u0010\u0006\n\u0002\u0008\u0003\n\u0002\u0010\u000e\n\u0002\u0008\u0003\n\u0002\u0010\u000b\n\u0002\u0010\u0000\n\u0002\u0008\u0003\u0008\u0087@\u0018\u0000 s2\u0008\u0012\u0004\u0012\u00020\u00000\u0001:\u0001sB\u0011\u0008\u0001\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J\u0018\u0010\u0008\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0087\n\u00a2\u0006\u0004\u0008\u000c\u0010\rJ\u0018\u0010\u0008\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0000H\u0097\n\u00a2\u0006\u0004\u0008\u000e\u0010\u000fJ\u0018\u0010\u0008\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0010H\u0087\n\u00a2\u0006\u0004\u0008\u0011\u0010\u0012J\u0018\u0010\u0008\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0013H\u0087\n\u00a2\u0006\u0004\u0008\u0014\u0010\u0015J\u0018\u0010\u0016\u001a\u00020\u00102\u0006\u0010\n\u001a\u00020\u000bH\u0087\n\u00a2\u0006\u0004\u0008\u0017\u0010\rJ\u0018\u0010\u0016\u001a\u00020\u00102\u0006\u0010\n\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008\u0018\u0010\u000fJ\u0018\u0010\u0016\u001a\u00020\u00102\u0006\u0010\n\u001a\u00020\u0010H\u0087\n\u00a2\u0006\u0004\u0008\u0019\u0010\u0012J\u0018\u0010\u0016\u001a\u00020\u00132\u0006\u0010\n\u001a\u00020\u0013H\u0087\n\u00a2\u0006\u0004\u0008\u001a\u0010\u001bJ\u0018\u0010\u001c\u001a\u00020\u00102\u0006\u0010\n\u001a\u00020\u000bH\u0087\n\u00a2\u0006\u0004\u0008\u001d\u0010\rJ\u0018\u0010\u001c\u001a\u00020\u00102\u0006\u0010\n\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008\u001e\u0010\u000fJ\u0018\u0010\u001c\u001a\u00020\u00102\u0006\u0010\n\u001a\u00020\u0010H\u0087\n\u00a2\u0006\u0004\u0008\u001f\u0010\u0012J\u0018\u0010\u001c\u001a\u00020\u00132\u0006\u0010\n\u001a\u00020\u0013H\u0087\n\u00a2\u0006\u0004\u0008 \u0010\u001bJ\u0018\u0010!\u001a\u00020\u00102\u0006\u0010\n\u001a\u00020\u000bH\u0087\n\u00a2\u0006\u0004\u0008\"\u0010\rJ\u0018\u0010!\u001a\u00020\u00102\u0006\u0010\n\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008#\u0010\u000fJ\u0018\u0010!\u001a\u00020\u00102\u0006\u0010\n\u001a\u00020\u0010H\u0087\n\u00a2\u0006\u0004\u0008$\u0010\u0012J\u0018\u0010!\u001a\u00020\u00132\u0006\u0010\n\u001a\u00020\u0013H\u0087\n\u00a2\u0006\u0004\u0008%\u0010\u001bJ\u0018\u0010&\u001a\u00020\u00102\u0006\u0010\n\u001a\u00020\u000bH\u0087\n\u00a2\u0006\u0004\u0008\'\u0010\rJ\u0018\u0010&\u001a\u00020\u00102\u0006\u0010\n\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008(\u0010\u000fJ\u0018\u0010&\u001a\u00020\u00102\u0006\u0010\n\u001a\u00020\u0010H\u0087\n\u00a2\u0006\u0004\u0008)\u0010\u0012J\u0018\u0010&\u001a\u00020\u00132\u0006\u0010\n\u001a\u00020\u0013H\u0087\n\u00a2\u0006\u0004\u0008*\u0010\u001bJ\u0018\u0010+\u001a\u00020\u00102\u0006\u0010\n\u001a\u00020\u000bH\u0087\n\u00a2\u0006\u0004\u0008,\u0010\rJ\u0018\u0010+\u001a\u00020\u00102\u0006\u0010\n\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008-\u0010\u000fJ\u0018\u0010+\u001a\u00020\u00102\u0006\u0010\n\u001a\u00020\u0010H\u0087\n\u00a2\u0006\u0004\u0008.\u0010\u0012J\u0018\u0010+\u001a\u00020\u00132\u0006\u0010\n\u001a\u00020\u0013H\u0087\n\u00a2\u0006\u0004\u0008/\u0010\u001bJ\u0018\u00100\u001a\u00020\u00102\u0006\u0010\n\u001a\u00020\u000bH\u0087\u0008\u00a2\u0006\u0004\u00081\u0010\rJ\u0018\u00100\u001a\u00020\u00102\u0006\u0010\n\u001a\u00020\u0000H\u0087\u0008\u00a2\u0006\u0004\u00082\u0010\u000fJ\u0018\u00100\u001a\u00020\u00102\u0006\u0010\n\u001a\u00020\u0010H\u0087\u0008\u00a2\u0006\u0004\u00083\u0010\u0012J\u0018\u00100\u001a\u00020\u00132\u0006\u0010\n\u001a\u00020\u0013H\u0087\u0008\u00a2\u0006\u0004\u00084\u0010\u001bJ\u0018\u00105\u001a\u00020\u000b2\u0006\u0010\n\u001a\u00020\u000bH\u0087\u0008\u00a2\u0006\u0004\u00086\u00107J\u0018\u00105\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u0000H\u0087\u0008\u00a2\u0006\u0004\u00088\u00109J\u0018\u00105\u001a\u00020\u00102\u0006\u0010\n\u001a\u00020\u0010H\u0087\u0008\u00a2\u0006\u0004\u0008:\u0010\u0012J\u0018\u00105\u001a\u00020\u00132\u0006\u0010\n\u001a\u00020\u0013H\u0087\u0008\u00a2\u0006\u0004\u0008;\u0010\u001bJ\u0010\u0010<\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008=\u0010\u0005J\u0010\u0010>\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008?\u0010\u0005J\u0018\u0010@\u001a\u00020A2\u0006\u0010\n\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008B\u0010CJ\u0018\u0010D\u001a\u00020A2\u0006\u0010\n\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008E\u0010CJ\u0018\u0010F\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u0000H\u0087\u000c\u00a2\u0006\u0004\u0008G\u00109J\u0018\u0010H\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u0000H\u0087\u000c\u00a2\u0006\u0004\u0008I\u00109J\u0018\u0010J\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u0000H\u0087\u000c\u00a2\u0006\u0004\u0008K\u00109J\u0010\u0010L\u001a\u00020\u0000H\u0087\u0008\u00a2\u0006\u0004\u0008M\u0010\u0005J\u0010\u0010N\u001a\u00020OH\u0087\u0008\u00a2\u0006\u0004\u0008P\u0010QJ\u0010\u0010R\u001a\u00020\u0003H\u0087\u0008\u00a2\u0006\u0004\u0008S\u0010\u0005J\u0010\u0010T\u001a\u00020\tH\u0087\u0008\u00a2\u0006\u0004\u0008U\u0010VJ\u0010\u0010W\u001a\u00020XH\u0087\u0008\u00a2\u0006\u0004\u0008Y\u0010ZJ\u0010\u0010[\u001a\u00020\u000bH\u0087\u0008\u00a2\u0006\u0004\u0008\\\u0010QJ\u0010\u0010]\u001a\u00020\u0000H\u0087\u0008\u00a2\u0006\u0004\u0008^\u0010\u0005J\u0010\u0010_\u001a\u00020\u0010H\u0087\u0008\u00a2\u0006\u0004\u0008`\u0010VJ\u0010\u0010a\u001a\u00020\u0013H\u0087\u0008\u00a2\u0006\u0004\u0008b\u0010ZJ\u0010\u0010c\u001a\u00020dH\u0087\u0008\u00a2\u0006\u0004\u0008e\u0010fJ\u0010\u0010g\u001a\u00020hH\u0087\u0008\u00a2\u0006\u0004\u0008i\u0010jJ\u000f\u0010k\u001a\u00020lH\u0016\u00a2\u0006\u0004\u0008m\u0010nJ\u0013\u0010o\u001a\u00020p2\u0008\u0010\n\u001a\u0004\u0018\u00010qH\u00d6\u0003J\t\u0010r\u001a\u00020\tH\u00d6\u0001R\u0016\u0010\u0002\u001a\u00020\u00038\u0000X\u0081\u0004\u00a2\u0006\u0008\n\u0000\u0012\u0004\u0008\u0006\u0010\u0007\u0088\u0001\u0002\u0092\u0001\u00020\u0003\u00a8\u0006t"
    }
    d2 = {
        "Lkotlin/UShort;",
        "",
        "data",
        "",
        "constructor-impl",
        "(S)S",
        "getData$annotations",
        "()V",
        "compareTo",
        "",
        "other",
        "Lkotlin/UByte;",
        "compareTo-7apg3OU",
        "(SB)I",
        "compareTo-xj2QHRw",
        "(SS)I",
        "Lkotlin/UInt;",
        "compareTo-WZ4Q5Ns",
        "(SI)I",
        "Lkotlin/ULong;",
        "compareTo-VKZWuLQ",
        "(SJ)I",
        "plus",
        "plus-7apg3OU",
        "plus-xj2QHRw",
        "plus-WZ4Q5Ns",
        "plus-VKZWuLQ",
        "(SJ)J",
        "minus",
        "minus-7apg3OU",
        "minus-xj2QHRw",
        "minus-WZ4Q5Ns",
        "minus-VKZWuLQ",
        "times",
        "times-7apg3OU",
        "times-xj2QHRw",
        "times-WZ4Q5Ns",
        "times-VKZWuLQ",
        "div",
        "div-7apg3OU",
        "div-xj2QHRw",
        "div-WZ4Q5Ns",
        "div-VKZWuLQ",
        "rem",
        "rem-7apg3OU",
        "rem-xj2QHRw",
        "rem-WZ4Q5Ns",
        "rem-VKZWuLQ",
        "floorDiv",
        "floorDiv-7apg3OU",
        "floorDiv-xj2QHRw",
        "floorDiv-WZ4Q5Ns",
        "floorDiv-VKZWuLQ",
        "mod",
        "mod-7apg3OU",
        "(SB)B",
        "mod-xj2QHRw",
        "(SS)S",
        "mod-WZ4Q5Ns",
        "mod-VKZWuLQ",
        "inc",
        "inc-Mh2AYeg",
        "dec",
        "dec-Mh2AYeg",
        "rangeTo",
        "Lkotlin/ranges/UIntRange;",
        "rangeTo-xj2QHRw",
        "(SS)Lkotlin/ranges/UIntRange;",
        "rangeUntil",
        "rangeUntil-xj2QHRw",
        "and",
        "and-xj2QHRw",
        "or",
        "or-xj2QHRw",
        "xor",
        "xor-xj2QHRw",
        "inv",
        "inv-Mh2AYeg",
        "toByte",
        "",
        "toByte-impl",
        "(S)B",
        "toShort",
        "toShort-impl",
        "toInt",
        "toInt-impl",
        "(S)I",
        "toLong",
        "",
        "toLong-impl",
        "(S)J",
        "toUByte",
        "toUByte-w2LRezQ",
        "toUShort",
        "toUShort-Mh2AYeg",
        "toUInt",
        "toUInt-pVg5ArA",
        "toULong",
        "toULong-s-VKNKU",
        "toFloat",
        "",
        "toFloat-impl",
        "(S)F",
        "toDouble",
        "",
        "toDouble-impl",
        "(S)D",
        "toString",
        "",
        "toString-impl",
        "(S)Ljava/lang/String;",
        "equals",
        "",
        "",
        "hashCode",
        "Companion",
        "kotlin-stdlib"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lkotlin/jvm/JvmInline;
.end annotation


# static fields
.field public static final Companion:Lkotlin/UShort$Companion;

.field public static final MAX_VALUE:S = -0x1s

.field public static final MIN_VALUE:S = 0x0s

.field public static final SIZE_BITS:I = 0x10

.field public static final SIZE_BYTES:I = 0x2


# instance fields
.field private final data:S


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lkotlin/UShort$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lkotlin/UShort$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lkotlin/UShort;->Companion:Lkotlin/UShort$Companion;

    return-void
.end method

.method private synthetic constructor <init>(S)V
    .registers 2
    .param p1, "data"    # S

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-short p1, p0, Lkotlin/UShort;->data:S

    return-void
.end method

.method private static final and-xj2QHRw(SS)S
    .registers 3
    .param p0, "arg0"    # S
    .param p1, "other"    # S

    .line 253
    and-int v0, p0, p1

    int-to-short v0, v0

    invoke-static {v0}, Lkotlin/UShort;->constructor-impl(S)S

    move-result v0

    return v0
.end method

.method public static final synthetic box-impl(S)Lkotlin/UShort;
    .registers 2

    new-instance v0, Lkotlin/UShort;

    invoke-direct {v0, p0}, Lkotlin/UShort;-><init>(S)V

    return-object v0
.end method

.method private static final compareTo-7apg3OU(SB)I
    .registers 4
    .param p0, "arg0"    # S
    .param p1, "other"    # B

    .line 47
    const v0, 0xffff

    and-int/2addr v0, p0

    and-int/lit16 v1, p1, 0xff

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->compare(II)I

    move-result v0

    return v0
.end method

.method private static final compareTo-VKZWuLQ(SJ)I
    .registers 7
    .param p0, "arg0"    # S
    .param p1, "other"    # J

    .line 72
    int-to-long v0, p0

    const-wide/32 v2, 0xffff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {v0, v1, p1, p2}, Ljava/lang/Long;->compareUnsigned(JJ)I

    move-result v0

    return v0
.end method

.method private static final compareTo-WZ4Q5Ns(SI)I
    .registers 3
    .param p0, "arg0"    # S
    .param p1, "other"    # I

    .line 64
    const v0, 0xffff

    and-int/2addr v0, p0

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    invoke-static {v0, p1}, Ljava/lang/Integer;->compareUnsigned(II)I

    move-result v0

    return v0
.end method

.method private compareTo-xj2QHRw(S)I
    .registers 4
    .param p1, "other"    # S

    invoke-virtual {p0}, Lkotlin/UShort;->unbox-impl()S

    move-result v0

    .line 54
    const v1, 0xffff

    and-int/2addr v0, v1

    and-int/2addr v1, p1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->compare(II)I

    move-result v0

    .line 56
    return v0
.end method

.method private static compareTo-xj2QHRw(SS)I
    .registers 4
    .param p0, "arg0"    # S
    .param p1, "other"    # S

    .line 56
    const v0, 0xffff

    and-int v1, p0, v0

    and-int/2addr v0, p1

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->compare(II)I

    move-result v0

    return v0
.end method

.method public static constructor-impl(S)S
    .registers 1

    return p0
.end method

.method private static final dec-Mh2AYeg(S)S
    .registers 2
    .param p0, "arg0"    # S

    .line 235
    add-int/lit8 v0, p0, -0x1

    int-to-short v0, v0

    invoke-static {v0}, Lkotlin/UShort;->constructor-impl(S)S

    move-result v0

    return v0
.end method

.method private static final div-7apg3OU(SB)I
    .registers 4
    .param p0, "arg0"    # S
    .param p1, "other"    # B

    .line 115
    const v0, 0xffff

    and-int/2addr v0, p0

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    and-int/lit16 v1, p1, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Integer;->divideUnsigned(II)I

    move-result v0

    return v0
.end method

.method private static final div-VKZWuLQ(SJ)J
    .registers 7
    .param p0, "arg0"    # S
    .param p1, "other"    # J

    .line 124
    int-to-long v0, p0

    const-wide/32 v2, 0xffff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {v0, v1, p1, p2}, Ljava/lang/Long;->divideUnsigned(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final div-WZ4Q5Ns(SI)I
    .registers 3
    .param p0, "arg0"    # S
    .param p1, "other"    # I

    .line 121
    const v0, 0xffff

    and-int/2addr v0, p0

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    invoke-static {v0, p1}, Ljava/lang/Integer;->divideUnsigned(II)I

    move-result v0

    return v0
.end method

.method private static final div-xj2QHRw(SS)I
    .registers 4
    .param p0, "arg0"    # S
    .param p1, "other"    # S

    .line 118
    const v0, 0xffff

    and-int v1, p0, v0

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    and-int/2addr v0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    invoke-static {v1, v0}, Ljava/lang/Integer;->divideUnsigned(II)I

    move-result v0

    return v0
.end method

.method public static equals-impl(SLjava/lang/Object;)Z
    .registers 4

    instance-of v0, p1, Lkotlin/UShort;

    const/4 v1, 0x0

    if-nez v0, :cond_6

    return v1

    :cond_6
    move-object v0, p1

    check-cast v0, Lkotlin/UShort;

    invoke-virtual {v0}, Lkotlin/UShort;->unbox-impl()S

    move-result v0

    if-eq p0, v0, :cond_10

    return v1

    :cond_10
    const/4 v0, 0x1

    return v0
.end method

.method public static final equals-impl0(SS)Z
    .registers 3

    if-ne p0, p1, :cond_4

    const/4 v0, 0x1

    goto :goto_5

    :cond_4
    const/4 v0, 0x0

    :goto_5
    return v0
.end method

.method private static final floorDiv-7apg3OU(SB)I
    .registers 4
    .param p0, "arg0"    # S
    .param p1, "other"    # B

    .line 161
    const v0, 0xffff

    and-int/2addr v0, p0

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    and-int/lit16 v1, p1, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Integer;->divideUnsigned(II)I

    move-result v0

    return v0
.end method

.method private static final floorDiv-VKZWuLQ(SJ)J
    .registers 7
    .param p0, "arg0"    # S
    .param p1, "other"    # J

    .line 182
    int-to-long v0, p0

    const-wide/32 v2, 0xffff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {v0, v1, p1, p2}, Ljava/lang/Long;->divideUnsigned(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final floorDiv-WZ4Q5Ns(SI)I
    .registers 3
    .param p0, "arg0"    # S
    .param p1, "other"    # I

    .line 175
    const v0, 0xffff

    and-int/2addr v0, p0

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    invoke-static {v0, p1}, Ljava/lang/Integer;->divideUnsigned(II)I

    move-result v0

    return v0
.end method

.method private static final floorDiv-xj2QHRw(SS)I
    .registers 4
    .param p0, "arg0"    # S
    .param p1, "other"    # S

    .line 168
    const v0, 0xffff

    and-int v1, p0, v0

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    and-int/2addr v0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    invoke-static {v1, v0}, Ljava/lang/Integer;->divideUnsigned(II)I

    move-result v0

    return v0
.end method

.method public static synthetic getData$annotations()V
    .registers 0

    return-void
.end method

.method public static hashCode-impl(S)I
    .registers 2

    invoke-static {p0}, Ljava/lang/Short;->hashCode(S)I

    move-result v0

    return v0
.end method

.method private static final inc-Mh2AYeg(S)S
    .registers 2
    .param p0, "arg0"    # S

    .line 227
    add-int/lit8 v0, p0, 0x1

    int-to-short v0, v0

    invoke-static {v0}, Lkotlin/UShort;->constructor-impl(S)S

    move-result v0

    return v0
.end method

.method private static final inv-Mh2AYeg(S)S
    .registers 2
    .param p0, "arg0"    # S

    .line 262
    not-int v0, p0

    int-to-short v0, v0

    invoke-static {v0}, Lkotlin/UShort;->constructor-impl(S)S

    move-result v0

    return v0
.end method

.method private static final minus-7apg3OU(SB)I
    .registers 4
    .param p0, "arg0"    # S
    .param p1, "other"    # B

    .line 89
    const v0, 0xffff

    and-int/2addr v0, p0

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    and-int/lit16 v1, p1, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    sub-int/2addr v0, v1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final minus-VKZWuLQ(SJ)J
    .registers 7
    .param p0, "arg0"    # S
    .param p1, "other"    # J

    .line 98
    int-to-long v0, p0

    const-wide/32 v2, 0xffff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    sub-long/2addr v0, p1

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final minus-WZ4Q5Ns(SI)I
    .registers 3
    .param p0, "arg0"    # S
    .param p1, "other"    # I

    .line 95
    const v0, 0xffff

    and-int/2addr v0, p0

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    sub-int/2addr v0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final minus-xj2QHRw(SS)I
    .registers 4
    .param p0, "arg0"    # S
    .param p1, "other"    # S

    .line 92
    const v0, 0xffff

    and-int v1, p0, v0

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    and-int/2addr v0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    sub-int/2addr v1, v0

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final mod-7apg3OU(SB)B
    .registers 4
    .param p0, "arg0"    # S
    .param p1, "other"    # B

    .line 192
    const v0, 0xffff

    and-int/2addr v0, p0

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    and-int/lit16 v1, p1, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Integer;->remainderUnsigned(II)I

    move-result v0

    int-to-byte v0, v0

    invoke-static {v0}, Lkotlin/UByte;->constructor-impl(B)B

    move-result v0

    return v0
.end method

.method private static final mod-VKZWuLQ(SJ)J
    .registers 7
    .param p0, "arg0"    # S
    .param p1, "other"    # J

    .line 219
    int-to-long v0, p0

    const-wide/32 v2, 0xffff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {v0, v1, p1, p2}, Ljava/lang/Long;->remainderUnsigned(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final mod-WZ4Q5Ns(SI)I
    .registers 3
    .param p0, "arg0"    # S
    .param p1, "other"    # I

    .line 210
    const v0, 0xffff

    and-int/2addr v0, p0

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    invoke-static {v0, p1}, Ljava/lang/Integer;->remainderUnsigned(II)I

    move-result v0

    return v0
.end method

.method private static final mod-xj2QHRw(SS)S
    .registers 4
    .param p0, "arg0"    # S
    .param p1, "other"    # S

    .line 201
    const v0, 0xffff

    and-int v1, p0, v0

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    and-int/2addr v0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    invoke-static {v1, v0}, Ljava/lang/Integer;->remainderUnsigned(II)I

    move-result v0

    int-to-short v0, v0

    invoke-static {v0}, Lkotlin/UShort;->constructor-impl(S)S

    move-result v0

    return v0
.end method

.method private static final or-xj2QHRw(SS)S
    .registers 3
    .param p0, "arg0"    # S
    .param p1, "other"    # S

    .line 256
    or-int v0, p0, p1

    int-to-short v0, v0

    invoke-static {v0}, Lkotlin/UShort;->constructor-impl(S)S

    move-result v0

    return v0
.end method

.method private static final plus-7apg3OU(SB)I
    .registers 4
    .param p0, "arg0"    # S
    .param p1, "other"    # B

    .line 76
    const v0, 0xffff

    and-int/2addr v0, p0

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    and-int/lit16 v1, p1, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    add-int/2addr v0, v1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final plus-VKZWuLQ(SJ)J
    .registers 7
    .param p0, "arg0"    # S
    .param p1, "other"    # J

    .line 85
    int-to-long v0, p0

    const-wide/32 v2, 0xffff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    add-long/2addr v0, p1

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final plus-WZ4Q5Ns(SI)I
    .registers 3
    .param p0, "arg0"    # S
    .param p1, "other"    # I

    .line 82
    const v0, 0xffff

    and-int/2addr v0, p0

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    add-int/2addr v0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final plus-xj2QHRw(SS)I
    .registers 4
    .param p0, "arg0"    # S
    .param p1, "other"    # S

    .line 79
    const v0, 0xffff

    and-int v1, p0, v0

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    and-int/2addr v0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    add-int/2addr v1, v0

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final rangeTo-xj2QHRw(SS)Lkotlin/ranges/UIntRange;
    .registers 6
    .param p0, "arg0"    # S
    .param p1, "other"    # S

    .line 239
    new-instance v0, Lkotlin/ranges/UIntRange;

    const v1, 0xffff

    and-int v2, p0, v1

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v2

    and-int/2addr v1, p1

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    const/4 v3, 0x0

    invoke-direct {v0, v2, v1, v3}, Lkotlin/ranges/UIntRange;-><init>(IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object v0
.end method

.method private static final rangeUntil-xj2QHRw(SS)Lkotlin/ranges/UIntRange;
    .registers 4
    .param p0, "arg0"    # S
    .param p1, "other"    # S

    .line 249
    const v0, 0xffff

    and-int v1, p0, v0

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    and-int/2addr v0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    invoke-static {v1, v0}, Lkotlin/ranges/URangesKt;->until-J1ME1BU(II)Lkotlin/ranges/UIntRange;

    move-result-object v0

    return-object v0
.end method

.method private static final rem-7apg3OU(SB)I
    .registers 4
    .param p0, "arg0"    # S
    .param p1, "other"    # B

    .line 132
    const v0, 0xffff

    and-int/2addr v0, p0

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    and-int/lit16 v1, p1, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Integer;->remainderUnsigned(II)I

    move-result v0

    return v0
.end method

.method private static final rem-VKZWuLQ(SJ)J
    .registers 7
    .param p0, "arg0"    # S
    .param p1, "other"    # J

    .line 153
    int-to-long v0, p0

    const-wide/32 v2, 0xffff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {v0, v1, p1, p2}, Ljava/lang/Long;->remainderUnsigned(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final rem-WZ4Q5Ns(SI)I
    .registers 3
    .param p0, "arg0"    # S
    .param p1, "other"    # I

    .line 146
    const v0, 0xffff

    and-int/2addr v0, p0

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    invoke-static {v0, p1}, Ljava/lang/Integer;->remainderUnsigned(II)I

    move-result v0

    return v0
.end method

.method private static final rem-xj2QHRw(SS)I
    .registers 4
    .param p0, "arg0"    # S
    .param p1, "other"    # S

    .line 139
    const v0, 0xffff

    and-int v1, p0, v0

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    and-int/2addr v0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    invoke-static {v1, v0}, Ljava/lang/Integer;->remainderUnsigned(II)I

    move-result v0

    return v0
.end method

.method private static final times-7apg3OU(SB)I
    .registers 4
    .param p0, "arg0"    # S
    .param p1, "other"    # B

    .line 102
    const v0, 0xffff

    and-int/2addr v0, p0

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    and-int/lit16 v1, p1, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    mul-int/2addr v0, v1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final times-VKZWuLQ(SJ)J
    .registers 7
    .param p0, "arg0"    # S
    .param p1, "other"    # J

    .line 111
    int-to-long v0, p0

    const-wide/32 v2, 0xffff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    mul-long/2addr v0, p1

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final times-WZ4Q5Ns(SI)I
    .registers 3
    .param p0, "arg0"    # S
    .param p1, "other"    # I

    .line 108
    const v0, 0xffff

    and-int/2addr v0, p0

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    mul-int/2addr v0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final times-xj2QHRw(SS)I
    .registers 4
    .param p0, "arg0"    # S
    .param p1, "other"    # S

    .line 105
    const v0, 0xffff

    and-int v1, p0, v0

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    and-int/2addr v0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    mul-int/2addr v1, v0

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final toByte-impl(S)B
    .registers 2
    .param p0, "arg0"    # S

    .line 274
    int-to-byte v0, p0

    return v0
.end method

.method private static final toDouble-impl(S)D
    .registers 3
    .param p0, "arg0"    # S

    .line 353
    const v0, 0xffff

    and-int/2addr v0, p0

    invoke-static {v0}, Lkotlin/UnsignedKt;->uintToDouble(I)D

    move-result-wide v0

    return-wide v0
.end method

.method private static final toFloat-impl(S)F
    .registers 3
    .param p0, "arg0"    # S

    .line 346
    const v0, 0xffff

    and-int/2addr v0, p0

    invoke-static {v0}, Lkotlin/UnsignedKt;->uintToDouble(I)D

    move-result-wide v0

    double-to-float v0, v0

    return v0
.end method

.method private static final toInt-impl(S)I
    .registers 2
    .param p0, "arg0"    # S

    .line 294
    const v0, 0xffff

    and-int/2addr v0, p0

    return v0
.end method

.method private static final toLong-impl(S)J
    .registers 5
    .param p0, "arg0"    # S

    .line 304
    int-to-long v0, p0

    const-wide/32 v2, 0xffff

    and-long/2addr v0, v2

    return-wide v0
.end method

.method private static final toShort-impl(S)S
    .registers 1
    .param p0, "arg0"    # S

    .line 284
    return p0
.end method

.method public static toString-impl(S)Ljava/lang/String;
    .registers 2
    .param p0, "arg0"    # S

    .line 355
    const v0, 0xffff

    and-int/2addr v0, p0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final toUByte-w2LRezQ(S)B
    .registers 2
    .param p0, "arg0"    # S

    .line 315
    int-to-byte v0, p0

    invoke-static {v0}, Lkotlin/UByte;->constructor-impl(B)B

    move-result v0

    return v0
.end method

.method private static final toUInt-pVg5ArA(S)I
    .registers 2
    .param p0, "arg0"    # S

    .line 328
    const v0, 0xffff

    and-int/2addr v0, p0

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final toULong-s-VKNKU(S)J
    .registers 5
    .param p0, "arg0"    # S

    .line 338
    int-to-long v0, p0

    const-wide/32 v2, 0xffff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final toUShort-Mh2AYeg(S)S
    .registers 1
    .param p0, "arg0"    # S

    .line 318
    return p0
.end method

.method private static final xor-xj2QHRw(SS)S
    .registers 3
    .param p0, "arg0"    # S
    .param p1, "other"    # S

    .line 259
    xor-int v0, p0, p1

    int-to-short v0, v0

    invoke-static {v0}, Lkotlin/UShort;->constructor-impl(S)S

    move-result v0

    return v0
.end method


# virtual methods
.method public bridge synthetic compareTo(Ljava/lang/Object;)I
    .registers 5
    .param p1, "other"    # Ljava/lang/Object;

    .line 14
    move-object v0, p1

    check-cast v0, Lkotlin/UShort;

    invoke-virtual {v0}, Lkotlin/UShort;->unbox-impl()S

    move-result v0

    invoke-virtual {p0}, Lkotlin/UShort;->unbox-impl()S

    move-result v1

    const v2, 0xffff

    and-int/2addr v1, v2

    and-int/2addr v0, v2

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->compare(II)I

    move-result v0

    return v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 3

    iget-short v0, p0, Lkotlin/UShort;->data:S

    invoke-static {v0, p1}, Lkotlin/UShort;->equals-impl(SLjava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public hashCode()I
    .registers 2

    iget-short v0, p0, Lkotlin/UShort;->data:S

    invoke-static {v0}, Lkotlin/UShort;->hashCode-impl(S)I

    move-result v0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 2

    .line 355
    iget-short v0, p0, Lkotlin/UShort;->data:S

    invoke-static {v0}, Lkotlin/UShort;->toString-impl(S)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final synthetic unbox-impl()S
    .registers 2

    iget-short v0, p0, Lkotlin/UShort;->data:S

    return v0
.end method

###### Class kotlin.UShort.Companion (kotlin.UShort$Companion)
.class public final Lkotlin/UShort$Companion;
.super Ljava/lang/Object;
.source "UShort.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlin/UShort;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Companion"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0002\u0008\u0002\u0008\u0086\u0003\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003R\u0010\u0010\u0004\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0004\n\u0002\u0010\u0006R\u0010\u0010\u0007\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0004\n\u0002\u0010\u0006R\u000e\u0010\u0008\u001a\u00020\tX\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\tX\u0086T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000b"
    }
    d2 = {
        "Lkotlin/UShort$Companion;",
        "",
        "<init>",
        "()V",
        "MIN_VALUE",
        "Lkotlin/UShort;",
        "S",
        "MAX_VALUE",
        "SIZE_BYTES",
        "",
        "SIZE_BITS",
        "kotlin-stdlib"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 19
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 2

    invoke-direct {p0}, Lkotlin/UShort$Companion;-><init>()V

    return-void
.end method
