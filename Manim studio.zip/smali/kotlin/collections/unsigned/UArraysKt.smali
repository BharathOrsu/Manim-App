###### Class kotlin.collections.unsigned.UArraysKt (kotlin.collections.unsigned.UArraysKt)
.class public final Lkotlin/collections/unsigned/UArraysKt;
.super Lkotlin/collections/unsigned/UArraysKt___UArraysKt;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "kotlin/collections/unsigned/UArraysKt___UArraysJvmKt",
        "kotlin/collections/unsigned/UArraysKt___UArraysKt"
    }
    k = 0x4
    mv = {
        0x2,
        0x1,
        0x0
    }
    pn = "kotlin.collections"
    xi = 0x31
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Lkotlin/collections/unsigned/UArraysKt___UArraysKt;-><init>()V

    return-void
.end method
