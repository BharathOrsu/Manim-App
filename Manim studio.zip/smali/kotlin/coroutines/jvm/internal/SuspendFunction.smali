###### Class kotlin.coroutines.jvm.internal.SuspendFunction (kotlin.coroutines.jvm.internal.SuspendFunction)
.class public interface abstract Lkotlin/coroutines/jvm/internal/SuspendFunction;
.super Ljava/lang/Object;
.source "ContinuationImpl.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\u0008a\u0018\u00002\u00020\u0001\u00a8\u0006\u0002"
    }
    d2 = {
        "Lkotlin/coroutines/jvm/internal/SuspendFunction;",
        "",
        "kotlin-stdlib"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation
